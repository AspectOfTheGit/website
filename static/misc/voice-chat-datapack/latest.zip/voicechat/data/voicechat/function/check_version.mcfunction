# On load. Compares the version of the datapack with the newest (according to the website)

execute unless data storage voicechat:data response{status_code:200} run return 1
execute store success score .version_check voicechat run data modify storage voicechat:data response.response set from storage voicechat:data version
execute if score .version_check voicechat matches 1 run tellraw @a[tag=is_dev] [{"color":"green","text":"⚠ There is a new version of "},{"color":"green","bold":true,"text":"Voice Chat"},{"color":"green","text":" available!\n"},{"color":"#00AA00","text":"It's recommended to use the latest version as older versions can break.\n"},{"color":"#00AA00","text":"You can download the latest version "},{"color":"green","underlined":true,"text":"here.\n",click_event:{action:"open_url",url:"https://aspectofthe.site/voice/datapack"}},{"color":"#777777","text":"This message is only visible to devs.",italic:true,shadow_color:[0,0,0,1]}]

scoreboard players reset .version_check voicechat