#> Macro function

$data modify storage voicechat:data body.players[-1].options set from storage voicechat:data additional[{UUID:$(UUID)}]
$data remove storage voicechat:data additional[{UUID:$(UUID)}]
