
# Additional Settings for players

Only use functions with an underscore before them.
NEVER use apply.mcfunction, it is ran automatically.

These are simple functions that you can use in your datapack
to modify the voice input and output of a user.

You do not have to use these; you can copy the command in the
function and change it how you want to implement it into your
code. It is recommended to do this.


# Additional Settings Usage

You only have to set an additional setting for a player once.
The setting will persist until the voice room closes. Even if the
player disconnects and reconnects, the setting will still be active.

That being said, you can keep setting it as much as you want if
it is more convenient to do so.

The functions you should use are macro functions, and require inputs
before they can be used. See the additional settings list below to
find out the inputs and effect of each function. If a function
needs a UUID, this is the UUID of the player you want to affect.
It should be in the form [I;0,0,0,0].


# Additional Settings List

> _set_mic_volume
Macro Inputs: UUID, volume
Change the volume of the player's microphone heard by everyone else.
You can use this to mute players by setting their volume to 0.

> _set_playback_volume
Macro Inputs: UUID, volume
Change the volume that the player hears.
