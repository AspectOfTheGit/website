#> For use in your own datapack

#> Macro function
# UUID - UUID of player to affect
# volume - Volume (0-100) to set the players mic volume as

$data merge storage voicechat:data {additional:[{UUID:$(UUID),output:{volume:$(volume)}}]}
