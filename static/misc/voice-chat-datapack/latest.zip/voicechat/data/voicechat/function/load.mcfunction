schedule clear voicechat:tick_players

gamerule maxCommandChainLength 10000000

scoreboard objectives add vc_connect trigger
scoreboard objectives add vc_disconnect trigger
scoreboard objectives add voicechat dummy
scoreboard objectives add __int__ dummy
scoreboard players set 4 __int__ 4

execute unless score .http_check voicechat matches 5 run scoreboard players set .http_check voicechat 4
scoreboard players set .http_check_streak voicechat 0

data modify storage voicechat:data headers.Content-Type set value "application/json"
data modify storage voicechat:data version set value "1.1"

execute unless data storage voicechat:data headers.token run tellraw @a[tag=is_dev,tag=!is_owner] [{"color":"gold","text":"⚠ No Token Found\n"},{"color":"red","text":"The owner must generate a voice token for this world\n"},{"color":"red","text":"and input it before voice chat can be used.\n"},{"color":"#777777","text":"This message is only visible to devs.",italic:true,shadow_color:[0,0,0,1]}]
execute unless data storage voicechat:data headers.token run tellraw @a[tag=is_owner] [{"color":"gold","text":"⚠ No Token Found\n"},{"color":"red","text":"You must "},{"color":"red","text":"generate a voice token","underlined":true,click_event:{action:"open_url",url:"https://aspectofthe.site/account"}},{"color":"red","text":" for this world\n"},{"color":"red","text":"and input it","underlined":true,click_event:{action:"suggest_command",command:"/data modify storage voicechat:data headers.token set value \"<insert token here>\""}},{"color":"red","text":" before voice chat can be used.\n"},{"color":"#777777","text":"This message is only visible to devs.",italic:true,shadow_color:[0,0,0,1]}]

http store voicechat:data response callback voicechat:check_version send "https://api.aspectofthe.site/voice/version" GET

schedule function voicechat:tick_players 4t replace
