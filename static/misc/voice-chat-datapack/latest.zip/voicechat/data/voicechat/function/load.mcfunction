schedule clear voicechat:tick_players

gamerule maxCommandChainLength 10000000

scoreboard objectives add vc_connect trigger
scoreboard objectives add vc_disconnect trigger
scoreboard objectives add voicechat dummy
scoreboard objectives add __int__ dummy
scoreboard players set 4 __int__ 4

execute unless score .http_check voicechat matches 5 run scoreboard players set .http_check voicechat 4
scoreboard players set .http_check_streak voicechat 0

data modify storage voicechat:data headers.Content-Type set value "application/json"
data modify storage voicechat:data version set value "1.0"

http store voicechat:data response callback voicechat:check_version send "https://api.aspectofthe.site/voice/version" GET

schedule function voicechat:tick_players 4t replace
