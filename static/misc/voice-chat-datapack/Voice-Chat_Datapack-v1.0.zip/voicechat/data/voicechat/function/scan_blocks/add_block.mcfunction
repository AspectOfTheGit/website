scoreboard players operation $bitmap voicechat *= 4 __int__
# Toggles bit to 1 if it's not air
execute if block ~ ~ ~ #voicechat:damping run return run scoreboard players add $bitmap voicechat 2
execute unless block ~ ~ ~ #voicechat:air run return run scoreboard players add $bitmap voicechat 1
#execute if block ~ ~ ~ #voicechat:reflecting run return run run scoreboard players add $bitmap voicechat 1