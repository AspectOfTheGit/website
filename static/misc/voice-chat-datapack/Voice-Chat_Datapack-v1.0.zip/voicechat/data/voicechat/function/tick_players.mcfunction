
# Check if HTTP was overridden
execute if data storage voicechat:data body.players[] if score .http_check voicechat matches 0 run scoreboard players add .http_check_streak voicechat 2
execute if data storage voicechat:data body.players[] if score .http_check voicechat matches 1 if score .http_check_streak voicechat matches 1.. run scoreboard players remove .http_check_streak voicechat 1
execute if data storage voicechat:data body.players[] if score .http_check voicechat matches 0 if score .http_check_streak voicechat matches 8.. run tellraw @a[tag=is_dev] [{"text":"⚠","color":"yellow"},{"text":" Voice Chat","bold":true,"color":"red"},{"text":" has detected other HTTP requests.\nThis can harm voice chat connectivity and reduce voice quality.","color":"red"},"\n",{"text":"If this message is in error, please ignore it.","color":"gold","hover_event":{"action":"show_text","value":"It may be caused by changes in tps for example."}},"\n",{"text":"This message is only visible to devs. ","italic":true,"color":"#777777"},{"text":"Don't show again","italic":true,"underlined":true,"color":"#666666","click_event":{"action":"run_command","command":"scoreboard players set .http_check voicechat 5"}}]
execute if data storage voicechat:data body.players[] if score .http_check voicechat matches 0 if score .http_check_streak voicechat matches 8.. run scoreboard players set .http_check voicechat 2

execute unless score .http_check voicechat matches 2.. run scoreboard players set .http_check voicechat 0
execute unless score .http_check voicechat matches 1 run schedule function voicechat:tick_players 2t replace

# Handling Connecting Players
tellraw @a[scores={vc_connect=1..}] [{color:"gray",text:"[Voice Chat] ",bold:true},{color:"blue",text:"Connecting to Voice Chat...",bold:false}]
tag @a[scores={vc_connect=1..}] add voicechat_player
scoreboard players reset @a[scores={vc_connect=1..}] vc_connect
# Handling Disconnecting Players
tellraw @a[scores={vc_disconnect=1..}] [{color:"gray",text:"[Voice Chat] ",bold:true},{color:"red",text:"Disconnected from Voice Chat",bold:false}]
tag @a[scores={vc_disconnect=1..}] remove voicechat_player
scoreboard players reset @a[scores={vc_disconnect=1..}] vc_disconnect

# Preparing Body
data modify storage voicechat:data body set value {players:[]}
data modify storage voicechat:data body.version set from storage voicechat:data version
execute as @a[tag=voicechat_player] at @s run function voicechat:player_tick

# Sending HTTP
execute if data storage voicechat:data body.players[] run scoreboard players set empty_vc_timeout voicechat 3
execute unless data storage voicechat:data body.players[] if score .empty_vc_timeout voicechat matches 1.. run scoreboard players remove .empty_vc_timeout voicechat 1
execute unless score .empty_vc_timeout voicechat matches 0 run http headers storage voicechat:data headers body storage voicechat:data body store voicechat:data response callback voicechat:send_links send "https://api.aspectofthe.site/voice/update" POST

# Enabling Triggers to Connect/Disconnect
scoreboard players enable @a[tag=!voicechat_player] vc_connect
scoreboard players enable @a[tag=voicechat_player] vc_disconnect

# delay when checking begins otherwise it fails for some reason
execute if score .http_check voicechat matches 3 run scoreboard players set .http_check voicechat 1
execute if score .http_check voicechat matches 4 run scoreboard players set .http_check voicechat 3