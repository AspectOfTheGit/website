# We schedule here to ensure HTTP error doesn't show due to latency or other factors
schedule function voicechat:tick_players 2t replace

execute unless score .http_check voicechat matches 2.. run scoreboard players set .http_check voicechat 1

execute unless data storage voicechat:data response{status_code:200} run return 1

function voicechat:send_link