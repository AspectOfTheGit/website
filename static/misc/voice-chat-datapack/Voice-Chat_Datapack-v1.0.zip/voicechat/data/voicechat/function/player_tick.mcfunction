execute anchored eyes run summon marker ^ ^ ^ {UUID:[I;1423669785,-1094694847,-1733324415,1841839615]}

data modify storage voicechat:data body.players append value {}
data modify storage voicechat:data body.players[-1].UUID set from entity @s UUID
data modify storage voicechat:data body.players[-1].Name set from entity @s bukkit.lastKnownName
data modify storage voicechat:data body.players[-1].Pos set from entity @s Pos
data modify storage voicechat:data body.players[-1].Eyes set from entity 54db7a19-bec0-4841-98af-91816dc83dff Pos
data modify storage voicechat:data body.players[-1].Rotation set from entity @s Rotation

kill 54db7a19-bec0-4841-98af-91816dc83dff

# Long Long Scan of Blocks in Cube Radius 4, First increments X, then Z, then Y, all from -4 to 4
# Kinda laggy, idk