data modify storage voicechat:data body[-1].environment append value 0
execute store result storage voicechat:data body[-1].environment[-1] int 1 run scoreboard players get $bitmap voicechat
scoreboard players reset $bitmap voicechat