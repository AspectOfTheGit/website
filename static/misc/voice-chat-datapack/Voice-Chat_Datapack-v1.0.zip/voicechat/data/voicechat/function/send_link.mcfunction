execute unless data storage voicechat:data response.response[] run return 1

function voicechat:tellraw_link with storage voicechat:data response.response[-1]
data remove storage voicechat:data response.response[-1]

function voicechat:send_link